## Installation

### Library

`gem install airplay`

## CLI

`gem install airplay-cli`
