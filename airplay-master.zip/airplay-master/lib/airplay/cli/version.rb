module Airplay
  module CLI
    VERSION = "1.0.2"
  end
end
